package krt.com.blogpostapp.Adapters;

import android.content.Context;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.koushikdutta.ion.Ion;
import com.squareup.picasso.Picasso;

import java.util.List;

import krt.com.blogpostapp.Models.PostModel;
import krt.com.blogpostapp.R;
import krt.com.blogpostapp.Utility.Constants;
import krt.com.blogpostapp.Utility.Utils;

/**
 * Created by bryden on 11/18/16.
 */

public class PostsAdapter extends BaseAdapter {

    List<PostModel> list;
    Context context;

    LayoutInflater layoutInflater;
    public PostsAdapter(List<PostModel> list, Context context) {
        this.list = list;
        this.context = context;
        layoutInflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public PostModel getItem(int i) {
        return list.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {


        if (view == null)
        {
            view = layoutInflater.inflate(R.layout.listitem, null);;
        }
        final ImageView imageView = (ImageView) view.findViewById(R.id.imageView2);
        TextView textView = (TextView) view.findViewById(R.id.textView);
        TextView textView1 = (TextView) view.findViewById(R.id.textView3);
        TextView textView2 = (TextView) view.findViewById(R.id.textView2);
        PostModel postModel = getItem(i);
        String str = postModel.getImage();
   //     Log.d("imageurk", postModel.getPostKey());
        Ion.with(context.getApplicationContext()).load(str).withBitmap().error(R.drawable.placeholder)
                .intoImageView(imageView);

//        if (str == null || str.equals(""))
//        {
//            imageView.setImageResource(R.drawable.placeholder);
//        }
//        else
//         imageView.setImageBitmap(Utils.decodeBase64(postModel.getImage()));
        textView.setText(postModel.getImageDescription());
        textView1.setText(postModel.getUsername());
        textView2.setText(postModel.getPostDate());

        return view;
    }
}
