package krt.com.blogpostapp.Utility;

import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.storage.StorageReference;

/**
 * Created by bryden on 11/18/16.
 */

public class Constants {
//    private String image;
//    private String imageDescription;
//    private String userkey;
//
//    private String postDate;
//    private String username;
    public final static String DB_BLOG = "BlogDB";
    public final static String DB_IMAGE = "BlogImage";
    public final static String field_username = "username";
    public final static String field_postimage = "image";
    public final static String field_postdate = "postDate";
    public final static String field_description = "imageDescription";
    public final static String field_userkey = "userkey";
    public final static String field_longitude = "longitude";
    public final static String field_latitude = "latitude";
    public final static String field_key = "postKey";

    public static String user_latitude;
    public static String user_longitude;
    public static String user_name;
    public static FirebaseUser currentUser;
    public static String USERID;
    public static String USERNAME;
    public static StorageReference storageReference;



}
