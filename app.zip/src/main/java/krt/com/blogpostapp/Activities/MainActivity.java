package krt.com.blogpostapp.Activities;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import krt.com.blogpostapp.R;

public class MainActivity extends BaseActivity {

    MediaPlayer mp        = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mp = MediaPlayer.create(this, R.raw.start_up);
        mp.start();
        new CountDownTimer(5000, 1000){
            @Override
            public void onTick(long l) {

            }

            @Override
            public void onFinish() {
                mp.reset();
                mp.release();

                Intent intent = new Intent(MainActivity.this, SignInActivity.class);
                startActivity(intent);
                finish();
            }
        }.start();
    }
}
