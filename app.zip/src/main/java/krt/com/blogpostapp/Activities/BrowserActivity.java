package krt.com.blogpostapp.Activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.List;

import krt.com.blogpostapp.Adapters.PostsAdapter;
import krt.com.blogpostapp.Models.PostModel;
import krt.com.blogpostapp.R;
import krt.com.blogpostapp.Utility.Constants;

public class BrowserActivity extends BaseActivity {

    ListView listView;
    PostsAdapter adapter;
    List<PostModel> list;
    int size;
    DatabaseReference ref;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_browser);
        ref = FirebaseDatabase.getInstance().getReference(Constants.DB_BLOG);

        Constants.storageReference = FirebaseStorage.getInstance().getReference(Constants.DB_IMAGE);
        initView();
    }

    private void initView() {
        listView = (ListView) findViewById(R.id.listView);

        getData();
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(BrowserActivity.this, DetailViewActivity.class);
                intent.putExtra("object", list.get(i));
                startActivity(intent);
            }
        });
    }
    private void getData()
    {
        ShowDialog();
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                list = new ArrayList<PostModel>(); size = 0;
                HideDialog();
                for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren())
                {
                    size++;
                    PostModel model = dataSnapshot1.getValue(PostModel.class);
                    list.add(model);
                }
                if (size > 0)
                {
                    adapter = new PostsAdapter(list, BrowserActivity.this);
                    listView.setAdapter(adapter);
                }

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    public void OnPostNew(View view)
    {
        Intent intent = new Intent(this, PostActivity.class);
        startActivity(intent);

    }
}
