package krt.com.blogpostapp.Activities;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.UserProfileChangeRequest;

import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.concurrent.TimeUnit;

import krt.com.blogpostapp.R;
import krt.com.blogpostapp.Utility.Constants;
import krt.com.blogpostapp.Utility.Utils;

public class SignUpActivity extends BaseActivity implements GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener, LocationListener{

    EditText editText1, editText2, editText3, editText4;

    String email, password, password_confirm, userName;
    FirebaseAuth auth;
    private static final int MY_PERMISSIONS_REQUEST_READ_CONTACTS = 100;
    private LocationManager locationManager;
    GoogleApiClient mGoogleApiClient;
    Location mylocation;
    GPSTracker tracker;
    LocationRequest mLocationRequest;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        auth = FirebaseAuth.getInstance();
        if (mGoogleApiClient == null) {
            // ATTENTION: This "addApi(AppIndex.API)"was auto-generated to implement the App Indexing API.
            // See https://g.co/AppIndexing/AndroidStudio for more information.
            mGoogleApiClient = new GoogleApiClient.Builder(this)
                    .addConnectionCallbacks(this)
                    .addOnConnectionFailedListener(this)
                    .addApi(LocationServices.API)
                    .addApi(AppIndex.API).build();

        }
        initView();
    }

    private void initView() {
        editText1 = (EditText) findViewById(R.id.editText);
        editText2 = (EditText) findViewById(R.id.editText2);
        editText3 = (EditText) findViewById(R.id.editText3);
        editText4 = (EditText) findViewById(R.id.editText5);
    }
    @Override
    protected void onStart() {
        super.onStart();
//        tracker = new GPSTracker(this);
        if (mGoogleApiClient != null) {
            mGoogleApiClient.connect();
        }



    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mGoogleApiClient != null)
            mGoogleApiClient.disconnect();
    }
    void buildlocation() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                Toast.makeText(this, "location disable", Toast.LENGTH_LONG).show();
                return;
            } else {
                mylocation = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);
//                Location lastLocation = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);
//            LatLng loc = new LatLng(21.356993, 72.826647);
                if (mylocation == null) {
                    Log.d("GPS","location is again null");
                    LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient, mLocationRequest, this);
                    Log.d("GPS", "Requested for updates");
                }
                else {
//                loc = new LatLng(location.getLatitude(),location.getLongitude());
//                    Toast.makeText(this, " " + mylocation.getLatitude() + " ," + mylocation.getLongitude(), Toast.LENGTH_SHORT).show();
                }
            }
        } else {
            tracker = new GPSTracker(this);
            mylocation = tracker.getLocation();
        }
        if (mylocation == null) {
            Constants.user_latitude = (String.format("%.3f", 0.0));
            Constants.user_longitude = (String.format("%.3f", 0.0));
            return;
        }
        final Double latitude = mylocation.getLatitude();
        final Double longitude = mylocation.getLongitude();
//        Toast.makeText(this, " " + latitude + " " + longitude, Toast.LENGTH_LONG).show();
        Constants.user_latitude = (String.format("%.3f", latitude));
        Constants.user_longitude = (String.format("%.3f", longitude));
    }
    @Override
    protected void onStop() {
        mGoogleApiClient.disconnect();
        super.onStop();
    }
    public void OnCreateAccount(View view)
    {
        if (isFormValid())
        {
//            Toast.makeText(getApplicationContext(), "Create", Toast.LENGTH_LONG).show();
            SignUp();
        }
    }

    private void SignUp() {
        ShowDialog();
        auth.createUserWithEmailAndPassword(email, password).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Log.d("error", e.getMessage());
            }
        }).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                HideDialog();
                if (task.isSuccessful())
                {
                    Constants.currentUser = task.getResult().getUser();
                    updateUI();
                }
                else
                {

                }
            }
        });

    }

    private void updateUI()
    {
        UserProfileChangeRequest profileChangeRequest = new UserProfileChangeRequest.Builder()
                .setDisplayName(userName)
                .build();
        Constants.currentUser.updateProfile(profileChangeRequest).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                Constants.user_name = userName;
                Intent intent  = new Intent(SignUpActivity.this, BrowserActivity.class);
                startActivity(intent);
                finish();
            }
        });

    }
    boolean isFormValid()
    {
        email = editText1.getText().toString().trim();
        password = editText2.getText().toString().trim();
        password_confirm = editText3.getText().toString().trim();
        userName = editText4.getText().toString().trim();
        if (!Utils.isEmailValid(email))
        {
            editText1.setError(getString(R.string.error_email));
            return false;
        }
        if (password.length() == 0)
        {
            editText2.setError(getString(R.string.error_password_empty));
            return false;
        }
        if (password.length() < 6)
        {
            editText2.setError(getString(R.string.error_password_length));
            return false;
        }
        if (!password.equals(password_confirm))
        {
            editText3.setError(getString(R.string.error_password_confrim));
            return false;
        }
        if (userName.isEmpty()) {
            editText4.setError(getString(R.string.username_error));
        }

        return true;
    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {
        mGoogleApiClient.connect();
        mLocationRequest = LocationRequest.create()
                .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
                .setInterval(10 * 1000)
                .setFastestInterval(1 * 1000);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                    ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.ACCESS_FINE_LOCATION)) {
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, MY_PERMISSIONS_REQUEST_READ_CONTACTS);
                } else {
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, MY_PERMISSIONS_REQUEST_READ_CONTACTS);
                }
            } else {
                buildlocation();
            }
        } else {
            buildlocation();
        }
        try {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return;
            }
//            Location location = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);

        } catch (Exception e) {
            Log.d("GPS", "Error in onConnected.  "+e.getMessage());

        }
    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    @Override
    public void onLocationChanged(Location location) {

    }
}
