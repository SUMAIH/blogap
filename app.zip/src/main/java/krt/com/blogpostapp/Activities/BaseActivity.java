package krt.com.blogpostapp.Activities;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;

import krt.com.blogpostapp.R;

/**
 * Created by bryden on 11/17/16.
 */

public class BaseActivity extends AppCompatActivity {

    public ProgressDialog progressDialog;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    public void ShowDialog()
    {
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage(getString(R.string.loading_message));
        progressDialog.show();
    }

    public void HideDialog()
    {
        progressDialog.dismiss();
    }
}
