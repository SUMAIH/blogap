package krt.com.blogpostapp.Activities;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.koushikdutta.ion.Ion;
import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;

import java.io.ByteArrayOutputStream;
import java.util.Map;

import krt.com.blogpostapp.Models.PostModel;
import krt.com.blogpostapp.R;
import krt.com.blogpostapp.Utility.Constants;
import krt.com.blogpostapp.Utility.Utils;

public class DetailViewActivity extends BaseActivity {

    PostModel model;
    ImageView imageView;
    TextView textView;
    MapView mapView;
    GoogleMap map ;
    double latitude, longitude;
    Bitmap bitmap;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_view);
        mapView = (MapView)  findViewById(R.id.mapView);
        mapView.onCreate(savedInstanceState);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setHomeButtonEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);
        Bundle bundle = getIntent().getExtras();
        model = (PostModel) bundle.get("object");
        bitmap = null;
        initview();
    }
    @Override
    public void onResume() {
        mapView.onResume();
        super.onResume();
    }
    @Override
    public void onPause() {
        super.onPause();
        mapView.onPause();
    }
    @Override
    public void onDestroy() {
        super.onDestroy();
        mapView.onDestroy();
    }
    @Override
    public void onLowMemory() {
        super.onLowMemory();
        mapView.onLowMemory();
    }

    private void initview() {
        textView = (TextView) findViewById(R.id.textView4);
        imageView = (ImageView) findViewById(R.id.imageView3);
        Log.d("location" , model.getLatitude() + " " + model.getLongitude());
        Ion.with(getApplicationContext()).load(model.getImage()).withBitmap().error(R.drawable.placeholder)
                .intoImageView(imageView);

        latitude = Double.valueOf(model.getLatitude());
        longitude = Double.valueOf(model.getLongitude());
        if (mapView != null)
        {
            mapView.getMapAsync(new OnMapReadyCallback() {
                @Override
                public void onMapReady(GoogleMap googleMap) {
                    map = googleMap;
                    googleMap.addMarker(new MarkerOptions()
                            .icon(BitmapDescriptorFactory.fromResource(R.drawable.pin_icon))
                            .position(new LatLng(latitude, longitude)));
                    googleMap.getUiSettings().setMyLocationButtonEnabled(false);
                    if (ActivityCompat.checkSelfPermission(DetailViewActivity.this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(DetailViewActivity.this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                        return ;
                    }

                    googleMap.setMyLocationEnabled(true);
                    googleMap.getUiSettings().setZoomControlsEnabled(true);
//                    MapsInitializer.initialize(DetailViewActivity.this);
//                    LatLngBounds.Builder builder = new LatLngBounds.Builder();
//                    builder.include(new LatLng(Double.valueOf(Constants.user_latitude), Double.valueOf(Constants.user_longitude)));
//                    LatLngBounds bounds = builder.build();
//                    int padding = 0;
//                    // Updates the location and zoom of the MapView
                    CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLng(new LatLng(latitude, longitude));
                    googleMap.moveCamera(cameraUpdate);
                }
            });
        }
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                imageView.setDrawingCacheEnabled(true);
                bitmap = imageView.getDrawingCache();
                if (bitmap == null)
                {
                    Toast.makeText(getApplicationContext(), "image is null", Toast.LENGTH_SHORT).show();
                    return;
                }
                AlertDialog.Builder builder = new AlertDialog.Builder(DetailViewActivity.this);
                builder.setMessage(R.string.save_alarm_message)
                        .setPositiveButton(R.string.btn_save, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                                Utils.storeImage(getApplicationContext(), bitmap);
                            }
                        }).setNegativeButton(R.string.btn_share, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        Intent share = new Intent(Intent.ACTION_SEND);
                        share.setType("image/jpeg");
                        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
                        String path = MediaStore.Images.Media.insertImage(getContentResolver(),
                                bitmap, "Title", null);
                        Uri imageUri =  Uri.parse(path);
                        share.putExtra(Intent.EXTRA_STREAM, imageUri);
                        startActivity(Intent.createChooser(share, "Select"));
                    }
                }).setNeutralButton(R.string.btn_cancel, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                }).show();
            }
        });



        textView.setText(model.getImageDescription());
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
//        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
       int id = item.getItemId();
        switch (id) {
            case android.R.id.home:
            {
                this.finish();
                return true;
            }

        }
        return super.onOptionsItemSelected(item);
    }


    public void onMapLoaded() {

    }
}
