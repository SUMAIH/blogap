package krt.com.blogpostapp.Activities;

import android.Manifest;
import android.app.ActionBar;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.location.Location;
import android.location.LocationManager;
import android.media.Image;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

import krt.com.blogpostapp.Models.PostModel;
import krt.com.blogpostapp.R;
import krt.com.blogpostapp.Utility.Constants;
import krt.com.blogpostapp.Utility.Utils;
import okhttp3.internal.Util;

public class PostActivity extends BaseActivity implements GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener, LocationListener {

    private static final int SELECT_FILE = 1001;
    private static final int REQUEST_CAMERA = 1002;
    private static final Object TAG = "GPS";
    ImageView imageView;
    EditText editText;
    Bitmap postImage;
    String postString;
    DatabaseReference databaseReference;
    private static final int MY_PERMISSIONS_REQUEST_READ_CONTACTS = 100;
    private LocationManager locationManager;
    GoogleApiClient mGoogleApiClient;
    Location mylocation;
    GPSTracker tracker;
    LocationRequest mLocationRequest;
    StorageReference storageRef;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post);
        android.support.v7.app.ActionBar actionBar = getSupportActionBar();
        actionBar.setHomeButtonEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);
        databaseReference = FirebaseDatabase.getInstance().getReference(Constants.DB_BLOG);
        if (mGoogleApiClient == null) {
            // ATTENTION: This "addApi(AppIndex.API)"was auto-generated to implement the App Indexing API.
            // See https://g.co/AppIndexing/AndroidStudio for more information.
            mGoogleApiClient = new GoogleApiClient.Builder(this)
                    .addConnectionCallbacks(this)
                    .addOnConnectionFailedListener(this)
                    .addApi(LocationServices.API)
                    .addApi(AppIndex.API).build();

        }

        initView();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId())
        {
            case android.R.id.home:
            {
                this.finish();
                return true;
            }
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onStart() {
        super.onStart();
//        tracker = new GPSTracker(this);
        if (mGoogleApiClient != null) {
            mGoogleApiClient.connect();
        }



    }

    public void SelectImage() {
        final CharSequence[] items = {"Take Photo", "Choose from Library",
                "Cancel"};
        AlertDialog.Builder builder = new AlertDialog.Builder(PostActivity.this);
        builder.setTitle("Add Photo!");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {
                boolean result = Utils.checkPermission(PostActivity.this);
                String userChoosenTask;
                if (items[item].equals("Take Photo")) {
                    userChoosenTask = "Take Photo";
                    if (result)
                        cameraIntent();
                } else if (items[item].equals("Choose from Library")) {
                    userChoosenTask = "Choose from Library";
                    if (result)
                        galleryIntent();
                } else if (items[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
//        - See more at: http://www.theappguruz.com/blog/android-take-photo-camera-gallery-code-sample#sthash.XoYkk1gN.dpuf
    }

    private void cameraIntent() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent, REQUEST_CAMERA);
    }

    private void galleryIntent() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);//
        startActivityForResult(Intent.createChooser(intent, "Select File"), SELECT_FILE);
    }

    //    - See more at: http://www.theappguruz.com/blog/android-take-photo-camera-gallery-code-sample#sthash.XoYkk1gN.dpuf
//    - See more at: http://www.theappguruz.com/blog/android-take-photo-camera-gallery-code-sample#sthash.XoYkk1gN.dpuf
    private void initView() {
        imageView = (ImageView) findViewById(R.id.imageView);
        editText = (EditText) findViewById(R.id.editText4);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SelectImage();
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mGoogleApiClient != null)
            mGoogleApiClient.disconnect();
    }

    void buildlocation() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                Toast.makeText(this, "location disable", Toast.LENGTH_LONG).show();
                return;
            } else {
                mylocation = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);
//                Location lastLocation = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);
//            LatLng loc = new LatLng(21.356993, 72.826647);
                if (mylocation == null) {
                    Log.d("GPS","location is again null");
                    LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient, mLocationRequest, this);
                    Log.d("GPS", "Requested for updates");
                }
                else {
//                loc = new LatLng(location.getLatitude(),location.getLongitude());
//                    Toast.makeText(this, " " + mylocation.getLatitude() + " ," + mylocation.getLongitude(), Toast.LENGTH_SHORT).show();
                }
            }
        } else {
            tracker = new GPSTracker(this);
            mylocation = tracker.getLocation();
        }
        if (mylocation == null) {
            Constants.user_latitude = (String.format("%.3f", 0.0));
            Constants.user_longitude = (String.format("%.3f", 0.0));
            return;
        }
        final Double latitude = mylocation.getLatitude();
        final Double longitude = mylocation.getLongitude();
//        Toast.makeText(this, " " + latitude + " " + longitude, Toast.LENGTH_LONG).show();
        Constants.user_latitude = (String.format("%.3f", latitude));
        Constants.user_longitude = (String.format("%.3f", longitude));
    }
    @Override
    protected void onStop() {
        mGoogleApiClient.disconnect();
        super.onStop();
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == SELECT_FILE)
                onSelectFromGalleryResult(data);
            else if (requestCode == REQUEST_CAMERA)
                onCaptureImageResult(data);
        }
    }

    @SuppressWarnings("deprecation")
    private void onSelectFromGalleryResult(Intent data) {
        Bitmap bm = null;
        if (data != null) {
            try {
                bm = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), data.getData());
                ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                bm.compress(Bitmap.CompressFormat.JPEG, 50, bytes);
                postImage = bm;
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        imageView.setImageBitmap(bm);
    }

    private void onCaptureImageResult(Intent data) {
        Bitmap thumbnail = (Bitmap) data.getExtras().get("data");
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        thumbnail.compress(Bitmap.CompressFormat.JPEG, 50, bytes);
        File destination = new File(Environment.getExternalStorageDirectory(),
                System.currentTimeMillis() + ".jpg");
        FileOutputStream fo;
        try {
            destination.createNewFile();
            fo = new FileOutputStream(destination);
            fo.write(bytes.toByteArray());
            fo.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        postImage = thumbnail;
        imageView.setImageBitmap(thumbnail);
    }

    String datakey;
    void uploadImage()
    {


    }
    //    - See more at: http://www.theappguruz.com/blog/android-take-photo-camera-gallery-code-sample#sthash.XoYkk1gN.dpuf
//    - See more at: http://www.theappguruz.com/blog/android-take-photo-camera-gallery-code-sample#sthash.XoYkk1gN.dpuf
//    - See more at: http://www.theappguruz.com/blog/android-take-photo-camera-gallery-code-sample#sthash.XoYkk1gN.dpuf
    public void OnPost(View view) {
        postString = editText.getText().toString();

        ShowDialog();
        String imageString;
//        postImage = imageView.getDrawingCache();
        if (postImage == null)
            imageString = "";
        else {
            imageString = Utils.encodeToBase64(postImage, Bitmap.CompressFormat.JPEG, 100);
        }

        imageView.buildDrawingCache();

        final PostModel postModel = new PostModel();

        postModel.setImageDescription(postString);
        postModel.setUserkey(Constants.currentUser.getUid());
        postModel.setUsername(Constants.user_name);
        Calendar calendar = Calendar.getInstance();
        Date date = calendar.getTime();
        String postDate = Utils.dateToString(date, "FULL");
        postModel.setPostDate(postDate);
        postModel.setLatitude(Constants.user_latitude);
        postModel.setLongitude(Constants.user_longitude);

        final DatabaseReference temp = databaseReference.push();
        datakey = temp.getKey();
        postImage = imageView.getDrawingCache();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        postImage.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] data = baos.toByteArray();

        final StorageReference storageReference =  Constants.storageReference.child(datakey + ".jpg");
        storageReference.putBytes(data).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                if (task.isSuccessful())
                {
                    Toast.makeText(getApplicationContext(), "Success", Toast.LENGTH_SHORT).show();
//                    finish();
                    postModel.setImage(task.getResult().getDownloadUrl().toString());
                    postModel.setPostKey(datakey);
                    OnUpload(postModel, temp);
                }
                HideDialog();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                HideDialog();
            }
        });



//        postModel.setImage(storageReference.getDownloadUrl().toString());
//        postModel.setPostKey(datakey);


    }

    public void OnUpload(PostModel model, DatabaseReference temp )
    {
        HashMap<String, String> map = PostModel.getHashMap(model);
        temp.setValue(map).addOnCompleteListener(this, new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {
                    Toast.makeText(getApplicationContext(), getString(R.string.post_success), Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Toast.makeText(getApplicationContext(), getString(R.string.post_fail), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    public void OnCancel(View view) {
        finish();
    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {
        mGoogleApiClient.connect();
        mLocationRequest = LocationRequest.create()
                .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
                .setInterval(10 * 1000)
                .setFastestInterval(1 * 1000);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                    ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.ACCESS_FINE_LOCATION)) {
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, MY_PERMISSIONS_REQUEST_READ_CONTACTS);
                } else {
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, MY_PERMISSIONS_REQUEST_READ_CONTACTS);
                }
            } else {
                buildlocation();
            }
        } else {
            buildlocation();
        }
        try {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return;
            }
//            Location location = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);

        } catch (Exception e) {
            Log.d("GPS", "Error in onConnected.  "+e.getMessage());

        }
    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    @Override
    public void onLocationChanged(Location location) {

    }
}
