package krt.com.blogpostapp.Models;

import java.io.Serializable;
import java.util.HashMap;

import krt.com.blogpostapp.Utility.Constants;

/**
 * Created by bryden on 11/18/16.
 */

public class PostModel implements Serializable{
    private String image;
    private String imageDescription;
    private String userkey;

    private String latitude;
    private String longitude;

    private String postDate;
    private String username;

    private String postKey;

    public PostModel(String image, String imageDescription, String userkey, String latitude, String longitude, String postDate, String username, String postKey) {
        this.image = image;
        this.imageDescription = imageDescription;
        this.userkey = userkey;
        this.latitude = latitude;
        this.longitude = longitude;
        this.postDate = postDate;
        this.username = username;
        this.postKey = postKey;
    }

    public String getPostKey() {
        return postKey;
    }

    public void setPostKey(String postKey) {
        this.postKey = postKey;
    }

    public PostModel(String image, String imageDescription, String userkey, String latitude, String longitude, String postDate, String username) {
        this.image = image;
        this.imageDescription = imageDescription;
        this.userkey = userkey;
        this.latitude = latitude;
        this.longitude = longitude;
        this.postDate = postDate;
        this.username = username;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public PostModel() {
    }

    public String getPostDate() {
        return postDate;
    }

    public void setPostDate(String postDate) {
        this.postDate = postDate;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getImageDescription() {
        return imageDescription;
    }

    public void setImageDescription(String imageDescription) {
        this.imageDescription = imageDescription;
    }

    public String getUserkey() {
        return userkey;
    }

    public void setUserkey(String userkey) {
        this.userkey = userkey;
    }

    public static  HashMap<String, String> getHashMap(PostModel model)
    {
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put(Constants.field_description, model.getImageDescription());
        hashMap.put(Constants.field_postdate, model.getPostDate());
        hashMap.put(Constants.field_postimage, model.getImage());
        hashMap.put(Constants.field_userkey, model.getUserkey());
        hashMap.put(Constants.field_username, model.getUsername());
        hashMap.put(Constants.field_latitude, model.getLatitude());
        hashMap.put(Constants.field_longitude, model.getLongitude());
        hashMap.put(Constants.field_key, model.getPostKey());
        return hashMap;
    }

}
